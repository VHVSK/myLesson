const getRootHandler = (req, res) => {
    res.send('Get root route');
};

module.exports = { getRootHandler };
