function mult(a, b) {
    return a * b;
}

module.exports = mult;
