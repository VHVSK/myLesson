export const humidity = 40;
export const isRaining = false;
