import fs from 'fs';
import path from 'path';

console.log(fs);
console.log(path);
