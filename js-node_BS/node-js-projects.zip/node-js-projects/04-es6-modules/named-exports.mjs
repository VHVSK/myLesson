const season = 'spring';
const temperature = 13;

export { season, temperature };
