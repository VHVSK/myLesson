const USERNAME = 'admin';
const PASSWORD = 'strong-password';
const DEFAULT_SERVER = 'http://localhost';

export default DEFAULT_SERVER;

export { USERNAME, PASSWORD };
