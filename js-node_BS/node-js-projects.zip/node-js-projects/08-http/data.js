const comments = [
    { id: 100, text: 'First comment', author: 'Bogdan' },
    { id: 526, text: 'Second comment', author: 'Alice' },
    { id: 724, text: 'Last comment', author: 'Bob' },
];

module.exports = comments;
